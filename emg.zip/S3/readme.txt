session_13_04_16_01_2018: high force; good
session_13_10_16_01_2018: high froce; good
session_13_18_16_01_2018: high force; good

low force:

session_13_26_16_01_2018 (almost as good)
session_13_31_16_01_2018 (good)
session_13_35_16_01_2018 (good)

MVC:

session_13_41_16_01_2018 (good)
