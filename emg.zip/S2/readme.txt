High
session_14_51_10_01_2018  (good)
session_15_01_10_01_2018 (10s delay)
session_15_10_10_01_2018 (10s delay)

Low
session_15_25_10_01_2018 (good)
session_15_32_10_01_2018 (good)
session_15_45_10_01_2018 (good)

MVC
session_15_54_10_01_2018 (good)